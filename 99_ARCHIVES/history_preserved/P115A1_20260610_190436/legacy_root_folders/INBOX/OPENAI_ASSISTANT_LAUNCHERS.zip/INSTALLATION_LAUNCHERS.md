# INSTALLATION LAUNCHERS

## COMMANDES À COPIER

Après avoir téléchargé `OPENAI_ASSISTANT_LAUNCHERS.zip` dans :

```text
H:\MAESTRO_WORKSPACE\INBOX\OPENAI_ASSISTANT_LAUNCHERS.zip
```

lance :

```powershell
$zip = "H:\MAESTRO_WORKSPACE\INBOX\OPENAI_ASSISTANT_LAUNCHERS.zip"
$extract = "H:\MAESTRO_WORKSPACE\INBOX\OPENAI_ASSISTANT_LAUNCHERS_EXTRACT"

Remove-Item -Recurse -Force $extract -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $extract | Out-Null

Expand-Archive -Path $zip -DestinationPath $extract -Force

Copy-Item -Force "$extract\TOOLS\OPENAI_ASSISTANT\*.cmd" "H:\MAESTRO_WORKSPACE\TOOLS\OPENAI_ASSISTANT\"
Copy-Item -Force "$extract\TOOLS\OPENAI_ASSISTANT\README_LAUNCHERS.md" "H:\MAESTRO_WORKSPACE\TOOLS\OPENAI_ASSISTANT\"

Test-Path "H:\MAESTRO_WORKSPACE\TOOLS\OPENAI_ASSISTANT\maestro_ask.cmd"
```

## RÉSULTAT ATTENDU

```text
True
```

## TEST

```powershell
H:\MAESTRO_WORKSPACE\TOOLS\OPENAI_ASSISTANT\maestro_ask_dry_run.cmd
```
