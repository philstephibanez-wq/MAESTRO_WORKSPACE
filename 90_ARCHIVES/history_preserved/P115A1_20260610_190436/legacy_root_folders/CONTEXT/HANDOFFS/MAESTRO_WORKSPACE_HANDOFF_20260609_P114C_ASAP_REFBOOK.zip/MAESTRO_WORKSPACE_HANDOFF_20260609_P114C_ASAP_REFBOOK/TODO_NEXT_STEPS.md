# TODO — ASAP_REF_BOOK / ASAP after P114C handoff

1. Verify current git state:
   - `H:\ASAP_REF_BOOK`
   - `H:\ASAP`

2. Do not push WIP checkpoint yet.

3. P114C3:
   - stabilize ASAP download/install page in RefBook;
   - use official release manifest;
   - no GitHub public download link;
   - all UI text translated.

4. P114D1:
   - implement ASAP Documentation I18N Provider;
   - language is explicit input;
   - no silent fallback;
   - missing translation = explicit error.

5. P114D2:
   - RefBook consumes localized ASAP documentation ViewModels;
   - remove RefBook-owned translations for ASAP technical descriptions.

6. Re-run strict language recipe for:
   - fr/en/es/de/uk/it/pl/cs
   - night/paper/ocean where relevant
   - pages home/api-reference/asset-diagnostics/legal/search/domain-fsm/symbol-6/download-install.
