# MAESTRO_WORKSPACE HANDOFF — ASAP_REF_BOOK / P114C

Date: 2026-06-09  
Projet: `ASAP_REF_BOOK` / documentation publique ASAP  
Repo local: `H:\ASAP_REF_BOOK`  
Repo public: `https://github.com/philstephibanez-wq/ASAP_REF_BOOK`  
Branche: `main`

---

## 1. État Git connu

Dernier état explicitement confirmé par l'utilisateur:

```text
On branch main
Your branch is ahead of 'origin/main' by 1 commit.
nothing to commit, working tree clean
```

Interprétation:
- un commit local checkpoint existe;
- il n'est pas encore poussé;
- le workspace était propre à ce moment-là.

🔴 IMPORTANT: avant toute nouvelle livraison, relancer:

```cmd
cd /d H:\ASAP_REF_BOOK

git status
git log --oneline -5
```

Ne pas `push` tant que les corrections P114C/P114D ne sont pas validées.

---

## 2. Règles de travail actives

Règles permanentes MAESTRO_WORKSPACE / ASAP:

- 1 couche = 1 métier
- 1 moteur = 1 responsabilité
- 1 objet = 1 contrat
- 1 frontière = 1 validation explicite
- 0 fallback silencieux
- 0 logique métier dans la représentation
- 0 helper local non contractuel
- 0 scorie après livraison
- 0 patch sans source de vérité
- 0 patch depuis ZIP partiel
- ne pas pousser GitHub sans validation utilisateur
- garder RefBook comme site public de consultation, pas comme application à installer

---

## 3. Décision d'architecture validée pendant P114C

### 3.1 RefBook ne s'installe pas

Correction importante utilisateur:

```text
RefBook ne s'installe pas; il se consulte sur internet.
```

Donc:
- la page `download-install` parle de l'installation de **ASAP Framework**, pas de RefBook;
- RefBook peut porter cette page éditoriale, car l'installation ASAP change peu;
- cette page doit récupérer dynamiquement les dépôts/packages d'installation et versions disponibles via manifeste officiel.

### 3.2 ASAP est la source de vérité documentaire

Décision validée:

```text
Les APIs d'ASAP doivent comporter la langue.
ASAP doit traduire lui-même sa documentation.
ASAP est la source de vérité.
```

Conséquence:
- RefBook ne doit pas traduire en dur les descriptions métier/API ASAP;
- RefBook doit afficher un ViewModel documentaire déjà localisé fourni par ASAP;
- pas de fallback silencieux;
- si une traduction documentaire manque côté ASAP, erreur explicite / audit bloquant.

---

## 4. Architecture cible

### 4.1 Flux documentation API

```text
ASAP
  -> expose DocumentationProvider(lang)
  -> retourne ViewModel documentaire localisé
  -> erreur explicite si langue non supportée ou traduction manquante

ASAP_REF_BOOK
  -> consomme le ViewModel
  -> rend HTML/Twig
  -> ne modifie pas le sens métier
```

Langues cibles actuelles:

```text
fr, en, es, de, uk, it, pl, cs
```

Code langue tchèque: `cs`.

### 4.2 Flux download/install

```text
ASAP_REF_BOOK
  -> page publique ?page=download-install
  -> lit content/refbook/releases/asap.json
  -> affiche versions, canaux, packages, checksums, options d'installation
  -> ne pointe pas vers GitHub pour l'utilisateur final
```

Manifeste cible:

```text
content/refbook/releases/asap.json
```

Futur endpoint public:

```text
https://asap.logandplay.org/releases/asap.json
```

Exemple de champs attendus:
- `product`
- `latest_version`
- `channels.stable.version`
- `channels.stable.package_url`
- `channels.stable.checksum_sha256`
- `channels.dev.version`
- `install_options`
- `requirements`

---

## 5. Version ASAP

ASAP officiel lu via `composer.json` du dépôt public ASAP:

```json
{
  "name": "logandplay/asap",
  "description": "ASAP PHP 8 framework core",
  "version": "0.1.0",
  "require": {
    "php": ">=8.0",
    "twig/twig": "^3.0"
  }
}
```

Version officielle connue à ce stade: `0.1.0`.

Objectif:
- RefBook affiche la version ASAP installée;
- RefBook affiche la dernière version officielle disponible;
- RefBook compare les deux;
- source installée: ASAP local / `composer.json` ou futur `VersionProvider`;
- source officielle: manifeste release public Log&Play, pas GitHub côté utilisateur final.

---

## 6. Problèmes constatés avant handoff

### 6.1 Chevauchement header/version

Screenshots utilisateur:
- badge `Powered by ASAP Framework`
- copyright
- chip version ASAP

Problème:
- le badge/chip chevauche le texte selon thème et largeur.

Correction proposée/livrée dans P114C2:
- layout vertical propre;
- chips non superposées;
- CSS header corrigé.

État exact d'application P114C2: à vérifier côté workspace.

### 6.2 Traductions encore incomplètes

Utilisateur a confirmé:
- il reste des descriptions en anglais dans les pages non anglaises;
- exemple tchèque: bloc `Kontrakt` avec descriptions anglaises:
  - `Conditions do not select ACL rules.`
  - `Conditions receive only the explicit AccessContext.`
  - `Condition failures must be explicit and must not be ignored silently.`
- les descriptions doivent être claires et traduites;
- si cela vient d'ASAP, il faut mettre ASAP à jour;
- pas de fallback ni bidouille.

Décision:
- ne pas continuer à corriger ces descriptions dans RefBook comme solution définitive;
- créer la couche documentaire multilingue côté ASAP.

---

## 7. Livraisons déjà produites dans ce chat

### P114B à P114B8

But:
- I18N public RefBook multi-langue;
- ajout `de`, `uk`, `it`, `pl`, `cs`;
- recette language;
- corrections de fuites allemandes/françaises/chemins locaux;
- page et thème paper/ocean/night.

Point important:
- un commit local checkpoint a été fait après une partie de ce travail.
- ne pas pousser tant que P114C/D non stabilisés.

### P114C1

Livraison fournie:
`P114C1_REFBOOK_I18N_AUDIT_ASAP_VERSION_DOWNLOAD_FOUNDATION_DROP_IN.zip`

But annoncé:
- page `download-install`;
- version installée lue depuis `<ASAP_ROOT>/composer.json`;
- dernière version officielle depuis `content/refbook/releases/asap.json`;
- canal download Log&Play sans lien GitHub public;
- check P114C1.

État d'application: à vérifier.

### P114C2

Livraison fournie:
`P114C2_REFBOOK_SOURCE_I18N_AND_HEADER_LAYOUT_DROP_IN.zip`

But annoncé:
- corriger chevauchement header/version;
- traduire explicitement certaines phrases source visibles;
- smoke bloquant si traduction source manquante.

⚠️ Décision postérieure:
- P114C2 peut rester comme correction temporaire UI, mais la stratégie définitive est de déplacer la responsabilité de traduction documentaire dans ASAP.

État d'application: à vérifier.

---

## 8. Prochaine suite recommandée

### P114C3 — Stabiliser RefBook download/install

Objectif:
- corriger la page download/install pour être clairement une page ASAP;
- supprimer toute ambiguïté “installer RefBook”;
- lire proprement `content/refbook/releases/asap.json`;
- afficher:
  - version installée;
  - dernière version officielle;
  - canaux stable/dev;
  - liens `/downloads/asap/...`;
  - checksum;
  - options d'installation;
  - vérification post-install;
  - diagnostic d'installation;
- textes UI traduits dans `fr/en/es/de/uk/it/pl/cs`.

À contrôler:
- aucun lien GitHub public dans la page download/install;
- aucun chemin local;
- pas de fallback `[*...]`;
- page lisible en thème paper/night/ocean.

### P114D1 — ASAP Documentation I18N Provider

Côté repo `H:\ASAP`.

Objectif:
- ajouter une API/provider documentaire multilingue officiel ASAP;
- entrée stricte: `lang`;
- langues: `fr/en/es/de/uk/it/pl/cs`;
- sortie: ViewModel documentaire localisé;
- pas de fallback silencieux;
- erreur explicite si traduction manquante;
- ASAP reste source de vérité des descriptions API/contrats/règles/erreurs.

Noms possibles:
- `ASAP\Documentation\DocumentationProvider`
- `ASAP\Documentation\DocumentationLocale`
- `ASAP\Documentation\DocumentationViewModel`
- `ASAP\Documentation\DocumentationCatalog`
- `ASAP\Documentation\DocumentationTranslationMissingException`

### P114D2 — RefBook consomme ASAP Doc Provider

Côté repo `H:\ASAP_REF_BOOK`.

Objectif:
- retirer la traduction “métier ASAP” du RefBook;
- RefBook consomme le ViewModel ASAP localisé;
- recettes vérifient que les pages techniques ne contiennent plus de descriptions brutes anglaises en langue non anglaise.

---

## 9. Commandes de reprise

```cmd
cd /d H:\ASAP_REF_BOOK

git status
git log --oneline -5
```

Pour vérifier les fichiers P114C éventuellement appliqués:

```cmd
cd /d H:\ASAP_REF_BOOK

dir content\refbook\releases
dir application\reference\templates\pages
dir tools\smoke\run_p114c*.cmd
```

Pour vérifier ASAP local:

```cmd
cd /d H:\ASAP

git status
type composer.json
```

---

## 10. À ne pas oublier

🔴 IMPORTANT:
- Ne pas pousser le commit WIP local tant que P114C/P114D ne sont pas validés.
- RefBook = site public, pas installable.
- ASAP Framework = produit à installer.
- Page download/install = portée par RefBook, alimentée par manifeste releases ASAP.
- Documentation API métier = portée par ASAP, pas traduite à la main dans RefBook.
- Les mots techniques contractuels peuvent rester en anglais uniquement s'ils sont des identifiants ou noms de concepts: `ASAP`, `RefBook`, `ViewModel`, `Twig`, `Router`, `LSTSA`, namespaces, routes, méthodes, états FSM.
- Les phrases explicatives publiques doivent être traduites.
