# MAESTRO_WORKSPACE — GLOBAL HANDOFF

Build: 2026-06-09 00:40 Europe/Paris  
Scope: ASAP + ASAP_REF_BOOK + MAESTRO_v5 + MO_KB_DAEMON / MO_KB_FRONT + server notes  
Status: checkpoint stable after ASAP P112Q3E4 HTTP.

---

## 0. Reprise immédiate

Dans un nouveau chat du projet `MAESTRO_WORKSPACE`, joindre ce ZIP puis coller :

```text
On reprend depuis ce handoff global MAESTRO_WORKSPACE.
Priorité proposée : P112Q3E5 — Router legacy vs Routing canonical audit.
Respect strict du contrat workspace, 0 fallback silencieux, pas de patch sans source de vérité.
Avant tout patch : relire le contrat workspace et inspecter la source live GitHub/local.
```

---

## 1. Règles permanentes MAESTRO_WORKSPACE

- Source de vérité obligatoire avant patch : GitHub ou ZIP/handoff live fourni.
- Pas de patch sans contexte source réel.
- Zéro fallback silencieux.
- Pas de “rustine” qui masque la cause racine.
- Un moteur / module / service / renderer ne fait que son métier officiel.
- Les wrappers automatisés doivent être observables et retourner un `ExitCode`.
- `.cmd` préféré à `.bat`.
- Pas de `pause` dans les wrappers automatisés ; seulement dans les variantes `_interactive.cmd`.
- Après chaque livraison :
  1. test ciblé,
  2. smoke,
  3. strict/audit si applicable,
  4. recette globale,
  5. recette delivery,
  6. nettoyage `var/`,
  7. commit/push seulement si clean.
- Ne pas committer `var/`, rapports générés, fichiers temporaires ou scories.
- Les docs de patch vont dans `DOC/` ou dossier projet dédié, pas à la racine `H:\`.

---

## 2. État ASAP — source GitHub

Repo public :
```text
https://github.com/philstephibanez-wq/ASAP
```

Branche :
```text
master
```

Dernier commit stable connu :
```text
a3a111a — P112Q3E4 Add RefBook HTTP metadata contract baseline
```

État validé :
```text
P112Q3E1 FSM      ✅ validé + poussé
P112Q3E2 ACL      ✅ validé + poussé
P112Q3E3 Routing  ✅ validé + poussé
P112Q3E3C wrapper ✅ validé + poussé
P112Q3E4 HTTP     ✅ validé + poussé
```

Dernier état Git local confirmé :
```text
On branch master
Your branch is up to date with 'origin/master'.
nothing to commit, working tree clean
```

---

## 3. ASAP — validations P112Q3E4 HTTP

Palier fermé :
```text
P112Q3E4 — HTTP RefBook metadata contract
```

Validation runtime complète :
```text
P112Q3E4_REFBOOK_HTTP_METADATA_CONTRACT_UNIT_OK
P112Q3E4_REFBOOK_HTTP_METADATA_SMOKE_OK
P112Q3E4_REFBOOK_HTTP_METADATA_STRICT_OK
ASAP_GLOBAL_REGRESSION_RECIPE_OK
P112Q3E4_DELIVERY_RECIPE_OK
ExitCode=0
```

Strict HTTP final :
```text
Classes=2
PublicMethods=7
ClassMetadataMissing=0
MethodMetadataMissing=0
Violations=0
LoadErrors=0
```

Classes HTTP couvertes :
```text
ASAP\Http\Request
ASAP\Http\Response
```

Corrections incluses dans le commit :
```text
P112Q3E4  — baseline HTTP metadata
P112Q3E4A — Response live symbol fix
P112Q3E4B — delivery marker alignment
P112Q3E4C — smoke marker alignment
```

Notes :
- Le premier patch n’avait couvert que `Request`.
- Le strict a correctement découvert `Response`.
- `Response` a été ajouté proprement à la couverture RefBook.
- Le marqueur final doit rester `P112Q3E4`, pas `P112Q3E4A/B/C`.

---

## 4. Prochaine étape ASAP recommandée

### Priorité proposée

```text
P112Q3E5 — Router legacy vs Routing canonical audit
```

Contexte :
- Il existe deux dossiers visibles côté ASAP :
  ```text
  framework/Asap/Router/
  framework/Asap/Routing/
  ```
- `Routing/` a déjà un palier RefBook validé.
- `Router/` semble être potentiellement legacy ou parallèle.
- Ne rien supprimer sans audit.
- Objectif : comprendre responsabilité réelle, usages, références, collisions de concepts, puis décider :
  - conserver comme domaine distinct,
  - migrer vers `Routing`,
  - documenter comme legacy,
  - ou déprécier proprement avec contrat.

### Commandes de reprise ASAP

```cmd
cd /d H:\ASAP
git status
tools\recipes\run_asap_global_regression_recipe.cmd
```

Résultat attendu :
```text
ASAP_GLOBAL_REGRESSION_RECIPE_OK
ExitCode=0
```

### Audit recommandé avant patch

```cmd
cd /d H:\ASAP
dir framework\Asap\Router /s
dir framework\Asap\Routing /s
findstr /S /N /I "ASAP\\Router Router\\ Routing\\ RouteDefinition RouteMatch" *.php *.xml *.md
git status
```

Puis inspecter précisément :
```text
framework/Asap/Router/*
framework/Asap/Routing/*
tests qui référencent Router/Routing
tools/smoke qui référencent Router/Routing
docs ou manifests qui référencent Router/Routing
```

---

## 5. ASAP_REF_BOOK

Repo public connu :
```text
https://github.com/philstephibanez-wq/ASAP_REF_BOOK
```

État mémoire :
- Dépôt public confirmé.
- Application documentaire créée et reliée à UwAmp.
- P113B7 probablement poussé/mis à jour sur GitHub public.
- Reprise recommandée après stabilisation ASAP :
  - consommer les snapshots/API RefBook générés par ASAP,
  - éviter d’inventer des descriptions qui ne viennent pas de Reflection + Attributes,
  - améliorer UI/doc avec source technique vérifiée.

À vérifier à la reprise :
```cmd
cd /d H:\ASAP_REF_BOOK
git status
git pull
```

---

## 6. MAESTRO_v5 / REAPER

Racine logique actuelle :
```text
C:\Users\steph\AppData\Roaming\REAPER\Scripts\MAESTRO_v5
```

Chemin physique via jonction :
```text
D:\REAPER_Roaming\REAPER
```

État mémoire important :
- REAPER fonctionne après migration Roaming vers D:.
- Maestro_v5 fonctionne.
- DB Browser for SQLite fonctionne sur D:.
- Bitdefender exception ajoutée sur `D:\REAPER_Roaming\REAPER`.
- Dépôt Git propre confirmé le 2026-06-04, mais à revérifier avant toute reprise.

Règles Maestro :
- No AGENTS, no patch.
- AGENTS.md 4.1.3 build 2026.05.08 ou contexte équivalent obligatoire avant patch.
- Kernel souverain.
- `SYS` bus runtime unique.
- `_G` interdit.
- Zéro fallback silencieux.
- Pas de checks défensifs framework dans modules/composants déjà chargés par Kernel.
- Boot Console pré-Factory.
- Workflow step-by-step, un palier à la fois.

Prochaine reprise Maestro_v5 éventuelle :
- Reprendre depuis le dernier handoff Maestro dédié, pas depuis ce handoff global seul.
- Ne pas patcher Maestro_v5 sans ZIP/AGENTS courant.

---

## 7. MO_KB_DAEMON / MO_KB_FRONT / ASAP front

Racines mémoire :
```text
H:\MO_KB_DAEMON
H:\MO_KB_STORE
H:\MO_KB_VENDOR
H:\MO_KB_FRONT
H:\MO_KB_FRONT_ASAP
H:\UwAmp
```

Décisions actives :
- Backend Python = REST headless + widget Qt minimal start/stop/diagnostic.
- UI web principale/backoffice = PHP/ASAP/UwAmp, pas HTML Python.
- Slaves via LAN privé/RCP/SSH/SFTP, pas Workgroup Windows.
- Slaves sous racine officielle :
  ```text
  C:\MO_KB_SLAVE
  C:\MO_KB_SLAVE\daemon
  C:\MO_KB_SLAVE\vendor
  C:\MO_KB_SLAVE\packages
  ```
- Master vérifie versions slaves et doit pouvoir mettre à jour via RCP sans intervention manuelle.
- Jobs lourds sur slaves, master coordonne/merge/ACK.
- Slaves ne modifient jamais la KB canonique.
- Logs session doivent s’écraser ou se purger selon contrat.
- Pas d’accumulation infinie dans spool/cache/tmp.

État mémoire récent :
- Local slave visible et capable de relais si aucun slave externe.
- Slave externe principal : `192.168.1.187`, nommé `MO_KB Slave 187`.
- Status 187 réglé dans une séance récente.
- Une ligne local slave manquait dans l’UI lors d’une reprise précédente.
- À reprendre depuis logs/ZIP dédiés MO_KB_DAEMON, pas depuis ce handoff seul.

---

## 8. Serveur / domaine / HTTPS

Contexte :
- Connexion via Freebox.
- HTTPS cible initiale : Cloudflare / Cloudflare Tunnel / certificat Cloudflare.
- OS : Windows 11.
- Antivirus : Bitdefender payant.
- L’utilisateur sait déjà utiliser WinSCP/SFTP/SSH.
- Configuration Freebox à guider pas à pas quand le chantier reprendra.

---

## 9. Commandes globales utiles

### ASAP stable check

```cmd
cd /d H:\ASAP
git status
tools\recipes\run_asap_global_regression_recipe.cmd
```

### ASAP_REF_BOOK check

```cmd
cd /d H:\ASAP_REF_BOOK
git status
```

### MO_KB_DAEMON check

```cmd
cd /d H:\MO_KB_DAEMON
git status
```

### MAESTRO_v5 check

```cmd
cd /d D:\REAPER_Roaming\REAPER\Scripts\MAESTRO_v5
git status
```

---

## 10. Risques connus / attention

- Ne pas confondre `Router/` et `Routing/`.
- Ne pas supprimer `Router/` sans audit des usages.
- Ne pas considérer `P112Q3E4A/B/C` comme marqueurs de domaine : le marqueur stable final est `P112Q3E4`.
- Ne pas committer `var/`.
- Les warnings Git LF -> CRLF sont habituels sous Windows, non bloquants.
- La commande `git restore -- var` peut répondre `pathspec 'var' did not match` si `var/` n’est pas suivi : c’est normal.
- RefBook : Reflection = vérité technique ; Attributes = descriptions fonctionnelles.
- ASAP_REF_BOOK ne doit pas inventer les signatures/classes : il doit consommer les snapshots/API ASAP.

---

## 11. Décision de reprise conseillée

Prochain palier recommandé :

```text
P112Q3E5 — Router legacy vs Routing canonical audit
```

Objectif :
1. inspecter les deux dossiers,
2. produire un rapport d’audit,
3. ne modifier aucun comportement au premier passage,
4. décider ensuite s’il faut un palier metadata `Router` ou un palier de dépréciation/migration.

Alternative :
```text
P112Q3E5 — Security / SecureDispatch RefBook metadata contract
```

Mais vu la découverte visuelle `Router/` vs `Routing/`, l’audit Router/Routing est prioritaire pour éviter de documenter/refactorer sur une base ambiguë.
