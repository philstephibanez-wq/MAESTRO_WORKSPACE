# CHECK COMMANDS

## ASAP

```cmd
cd /d H:\ASAP
git status
tools\recipes\run_asap_global_regression_recipe.cmd
```

## ASAP HTTP specific

```cmd
cd /d H:\ASAP
tests\Contract\run_refbook_http_metadata_contract_test.cmd
tools\smoke\run_p112q3e4_refbook_http_metadata_smoke.cmd
tools\refbook\run_p112q3e4_refbook_http_metadata_strict.cmd
tools\recipes\run_p112q3e4_delivery_recipe.cmd
```

## Clean generated files

```cmd
cd /d H:\ASAP
git restore -- var
git clean -fd -- var
git status
```

If `pathspec 'var' did not match`, it usually means `var/` is not tracked.

## No var staged

```cmd
git diff --cached --name-only | findstr /R "^var/"
```

Expected: no output.
