# NEXT ACTIONS

## Immediate

```cmd
cd /d H:\ASAP
git status
tools\recipes\run_asap_global_regression_recipe.cmd
```

## Recommended next palier

```text
P112Q3E5 — Router legacy vs Routing canonical audit
```

## Audit first, no patch first

```cmd
cd /d H:\ASAP
dir framework\Asap\Router /s
dir framework\Asap\Routing /s
findstr /S /N /I "ASAP\\Router Router\\ Routing\\ RouteDefinition RouteMatch" *.php *.xml *.md
```

Then inspect:
```text
framework/Asap/Router/*
framework/Asap/Routing/*
tests/*
tools/*
DOC/*
MANIFEST.md
```

## After audit

Decide one of:
```text
1. Router is legacy and must be documented/deprecated.
2. Router is a distinct domain and needs its own RefBook contract.
3. Router must be migrated into Routing with explicit compatibility plan.
4. Router is dead code, but deletion requires proof and a dedicated cleanup palier.
```
