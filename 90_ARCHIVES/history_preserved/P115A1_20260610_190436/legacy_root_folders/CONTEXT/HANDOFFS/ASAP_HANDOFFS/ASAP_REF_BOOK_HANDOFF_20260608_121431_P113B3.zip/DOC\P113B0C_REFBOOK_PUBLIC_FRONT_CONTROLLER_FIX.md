# P113B0C — RefBook public front controller fix

`public/index.php` is rewritten as a strict bootstrap-only front controller with `declare(strict_types=1);` immediately after `<?php`.

No route interception. No Markdown renderer. No parallel runtime.
