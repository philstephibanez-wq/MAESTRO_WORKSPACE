# P113B2 — RefBook navigation without `.htaccess`

## Goal

Make guides, domains and symbols reachable without Apache rewrite.

## Contract

URLs use query navigation:

```text
/ASAP_REF_BOOK/?page=api-reference
/ASAP_REF_BOOK/?page=guide-architecture
/ASAP_REF_BOOK/?page=domain-fsm
/ASAP_REF_BOOK/?page=symbol-0
```

## Scope

Only `H:\ASAP_REF_BOOK`.

No Apache.
No UwAmp.
No `httpd.conf`.
No `.htaccess`.