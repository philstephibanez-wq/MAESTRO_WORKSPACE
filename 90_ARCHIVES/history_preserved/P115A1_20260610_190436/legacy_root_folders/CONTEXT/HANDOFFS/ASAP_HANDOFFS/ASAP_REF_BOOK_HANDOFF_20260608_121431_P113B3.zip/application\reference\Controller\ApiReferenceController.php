<?php
declare(strict_types=1);

namespace ASAPRefBook\Reference\Controller;

use ASAP\Http\Request;
use ASAP\Renderer\ViewModel;

/**
 * PUBLIC CONTROLLER
 *
 * Role:
 *   Render the API reference entry page.
 *
 * Contract:
 *   Controller only. Official data comes from the ASAP source manifest.
 */
final class ApiReferenceController extends AbstractRefBookController
{
    /**
     * @param array<string,string> $params
     */
    public function index(Request $request, array $params): ViewModel
    {
        return $this->view('pages/api-reference.twig', [
            'title' => $this->content()->t('api.title'),
            'overview' => $this->catalog()->overview(),
        ]);
    }
}