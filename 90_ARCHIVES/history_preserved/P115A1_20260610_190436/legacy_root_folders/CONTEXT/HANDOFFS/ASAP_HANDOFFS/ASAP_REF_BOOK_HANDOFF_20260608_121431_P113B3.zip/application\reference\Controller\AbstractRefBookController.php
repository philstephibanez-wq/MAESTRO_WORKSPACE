<?php
declare(strict_types=1);

namespace ASAPRefBook\Reference\Controller;

use ASAP\Application\ApplicationPaths;
use ASAP\Renderer\ViewModel;
use ASAP\Template\TemplateRendererInterface;
use ASAPRefBook\Reference\Service\ManifestRepository;
use ASAPRefBook\Reference\Service\ReferenceCatalogService;
use ASAPRefBook\Reference\Service\ReferenceContentService;
use RuntimeException;

/**
 * INTERNAL CONTROLLER BASE
 *
 * Role:
 *   Share RefBook controller dependencies.
 *
 * Contract:
 *   Controller helper only. Business preparation stays in services.
 */
abstract class AbstractRefBookController
{
    public function __construct(
        protected readonly ApplicationPaths $paths,
        protected readonly TemplateRendererInterface $templateRenderer
    ) {
    }

    protected function language(): string
    {
        $language = (string) ($_GET['lang'] ?? ReferenceContentService::DEFAULT_LANGUAGE);

        if (!in_array($language, ReferenceContentService::SUPPORTED_LANGUAGES, true)) {
            throw new RuntimeException('ASAP_REFBOOK_LANG_UNSUPPORTED=' . $language);
        }

        return $language;
    }

    protected function content(): ReferenceContentService
    {
        return new ReferenceContentService($this->paths->appRoot . '/content/refbook/i18n', $this->language());
    }

    protected function catalog(): ReferenceCatalogService
    {
        return new ReferenceCatalogService(
            new ManifestRepository($this->paths->appRoot . '/var/data/api_reference.generated.json'),
            $this->content()
        );
    }

    /**
     * @param array<string,mixed> $data
     */
    protected function view(string $template, array $data, int $status = 200): ViewModel
    {
        $overview = $this->catalog()->overview();
        $content = $this->content();

        $data['basePath'] = '/ASAP_REF_BOOK';
        $data['lang'] = $content->language();
        $data['languages'] = $content->supportedLanguages();
        $data['pageSlug'] = (string) ($_GET['page'] ?? '');
        $data['ui'] = $content->labels();
        $data['moduleTitle'] = (string) ($content->module()['title'] ?? 'ASAP Reference Book');
        $data['module'] = $content->module();
        $data['navigationDomains'] = $overview['domains'];
        $data['navigationGuides'] = $content->guideNavigation();

        return new ViewModel($template, $data, $status);
    }
}