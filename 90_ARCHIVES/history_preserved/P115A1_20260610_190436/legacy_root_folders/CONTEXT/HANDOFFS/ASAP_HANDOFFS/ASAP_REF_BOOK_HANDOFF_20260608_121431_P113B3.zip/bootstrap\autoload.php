<?php
declare(strict_types=1);

/*
 * ASAP_REF_BOOK bootstrap autoloader.
 *
 * Contract:
 * - loads ASAP framework classes from ASAP_ROOT
 * - loads RefBook MVC classes from this application
 * - optionally loads official Composer vendor autoload when present
 * - does not emulate Twig and does not provide fallback rendering
 */

$refbookRoot = dirname(__DIR__);
$asapRoot = getenv('ASAP_ROOT') ?: 'H:\\ASAP';

$refbookVendor = $refbookRoot . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
$asapVendor = rtrim($asapRoot, "\\/") . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';

if (is_file($refbookVendor)) {
    require_once $refbookVendor;
} elseif (is_file($asapVendor)) {
    require_once $asapVendor;
}

spl_autoload_register(static function (string $class) use ($asapRoot, $refbookRoot): void {
    $prefixes = [
        'ASAP\\' => rtrim($asapRoot, "\\/") . DIRECTORY_SEPARATOR . 'framework' . DIRECTORY_SEPARATOR . 'Asap',
        'ASAPRefBook\\Reference\\' => $refbookRoot . DIRECTORY_SEPARATOR . 'application' . DIRECTORY_SEPARATOR . 'reference',
    ];

    foreach ($prefixes as $prefix => $root) {
        if (!str_starts_with($class, $prefix)) {
            continue;
        }

        $relative = substr($class, strlen($prefix));
        $file = $root . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $relative) . '.php';

        if (is_file($file)) {
            require_once $file;
        }

        return;
    }
});
