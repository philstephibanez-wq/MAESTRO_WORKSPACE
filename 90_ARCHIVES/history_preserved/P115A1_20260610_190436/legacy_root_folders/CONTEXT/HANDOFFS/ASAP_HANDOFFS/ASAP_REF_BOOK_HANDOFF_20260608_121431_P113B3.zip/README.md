# ASAP_REF_BOOK

Application neuve du Reference Book ASAP.

Contrat d'exécution :

```text
ASAP Application
→ SiteResolver
→ Router
→ ControllerDispatcher
→ Controller
→ Service
→ ViewModel
→ TwigTemplateRenderer
→ HTML Response
```

Cette application ne réutilise pas l'ancien RefBook.
"# ASAP_REF_BOOK" 
