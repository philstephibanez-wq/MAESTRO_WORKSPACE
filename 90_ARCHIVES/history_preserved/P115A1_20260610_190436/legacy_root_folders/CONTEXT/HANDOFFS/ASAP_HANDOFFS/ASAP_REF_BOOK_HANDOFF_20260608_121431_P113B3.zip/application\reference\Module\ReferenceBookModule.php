<?php
declare(strict_types=1);

namespace ASAPRefBook\Reference\Module;

/**
 * PUBLIC MODULE
 *
 * Role:
 *   Identify the ASAP Reference Book application module.
 *
 * Contract:
 *   Metadata only. No routing, no rendering, no filesystem access.
 */
final class ReferenceBookModule
{
    public function id(): string
    {
        return 'asap-reference-book';
    }

    public function title(): string
    {
        return 'ASAP Reference Book';
    }
}
