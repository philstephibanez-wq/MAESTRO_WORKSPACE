# P113B2B — Windows smoke fix

## Cause

The previous smoke used `php -r` with shell quoting that is not reliable in `cmd.exe`.
Windows interpreted the inline code incorrectly and PHP received a malformed command.

## Fix

The smoke now writes a temporary PHP child script per route and runs it with `php file.php`.

## Scope

Only `H:\ASAP_REF_BOOK`.

No Apache.
No UwAmp.
No `httpd.conf`.
No `.htaccess`.