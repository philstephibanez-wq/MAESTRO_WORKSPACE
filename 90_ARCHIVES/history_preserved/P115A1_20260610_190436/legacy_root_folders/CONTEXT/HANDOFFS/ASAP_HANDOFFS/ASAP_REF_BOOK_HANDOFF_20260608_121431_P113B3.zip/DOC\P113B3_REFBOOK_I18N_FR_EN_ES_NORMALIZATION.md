# P113B3 — RefBook I18N FR/EN/ES

## But

Normaliser le RefBook pour afficher une seule langue cohérente à la fois.

## Contrat

- Langue par défaut : `fr`
- Langues supportées : `fr`, `en`, `es`
- Navigation sans `.htaccess`
- URLs :
  - `/ASAP_REF_BOOK/?lang=fr`
  - `/ASAP_REF_BOOK/?lang=en&page=api-reference`
  - `/ASAP_REF_BOOK/?lang=es&page=domain-fsm`

## Portée

Uniquement `H:\ASAP_REF_BOOK`.

Aucun Apache.
Aucun UwAmp.
Aucun `httpd.conf`.
Aucun `.htaccess`.

## Source des textes

```text
content/refbook/i18n/fr.json
content/refbook/i18n/en.json
content/refbook/i18n/es.json
```