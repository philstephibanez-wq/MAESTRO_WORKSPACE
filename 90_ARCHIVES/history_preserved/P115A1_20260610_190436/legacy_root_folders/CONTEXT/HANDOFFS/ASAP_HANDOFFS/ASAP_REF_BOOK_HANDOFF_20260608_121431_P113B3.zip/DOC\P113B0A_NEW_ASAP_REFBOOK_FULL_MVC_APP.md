# P113B0A — New ASAP_REF_BOOK full MVC app

## Objectif

Recréer `H:\ASAP_REF_BOOK` complet, propre, local, sans l'ancien dépôt et sans dette Q2.

## Contrat

```text
ASAP Application
→ SiteResolver
→ Router
→ ControllerDispatcher
→ Controller
→ Service
→ ViewModel
→ TwigTemplateRenderer
→ HTML Response
```

## Dépendance runtime

Le rendu réel Twig nécessite l'installation officielle de Twig via Composer.
Aucun faux Twig n'est fourni.
