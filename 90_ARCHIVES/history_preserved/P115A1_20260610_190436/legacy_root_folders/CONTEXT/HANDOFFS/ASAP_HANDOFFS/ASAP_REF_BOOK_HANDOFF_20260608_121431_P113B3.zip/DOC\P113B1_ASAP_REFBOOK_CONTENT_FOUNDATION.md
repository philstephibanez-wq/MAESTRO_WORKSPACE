# P113B1 — ASAP RefBook Content Foundation

Scope: only H:\ASAP_REF_BOOK. No Apache, no UwAmp, no httpd.conf, no global .htaccess.

Adds structured content, guide pages, domain descriptions, richer home/API/domain/symbol pages.
