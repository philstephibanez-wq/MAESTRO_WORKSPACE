<?php
declare(strict_types=1);

namespace ASAPRefBook\Reference\Service;

final class ReferenceCatalogService
{
    public function __construct(private readonly ManifestRepository $repository, private readonly ?ReferenceContentService $content = null) {}

    public function overview(): array
    {
        $manifest = $this->repository->load();
        $domains = $this->domains($manifest);
        return ['manifest'=>$manifest,'domains'=>$domains,'symbol_count'=>count($this->symbols($manifest)),'domain_count'=>count($domains)];
    }

    public function domainBySlug(string $slug): ?array { foreach ($this->domains($this->repository->load()) as $domain) { if ($domain['slug'] === $slug) return $domain; } return null; }
    public function symbolByIndex(int $index): ?array { $symbols=$this->symbols($this->repository->load()); if (!isset($symbols[$index])) return null; $symbols[$index]['index']=$index; return $symbols[$index]; }

    private function domains(array $manifest): array
    {
        $names=[]; foreach ($this->symbols($manifest) as $symbol) { $names[trim((string)($symbol['domain'] ?? 'CORE'))]=true; }
        $domains=[];
        foreach (array_keys($names) as $name) {
            $domainSymbols=[];
            foreach ($this->symbols($manifest) as $index=>$symbol) { if ((string)($symbol['domain'] ?? 'CORE') !== $name) continue; $symbol['index']=$index; $domainSymbols[]=$symbol; }
            $domains[]=['name'=>$name,'slug'=>$this->slug($name),'symbols'=>$domainSymbols,'count'=>count($domainSymbols),'description'=>$this->content?->domainDescription($name) ?? 'Domaine ASAP à documenter depuis les balises source.'];
        }
        usort($domains, static fn(array $a,array $b): int => strcmp((string)$a['name'],(string)$b['name']));
        return $domains;
    }
    private function symbols(array $manifest): array { return array_values(array_filter($manifest['symbols'] ?? [], static fn(mixed $symbol): bool => is_array($symbol))); }
    private function slug(string $value): string { return trim(strtolower(preg_replace('/[^A-Za-z0-9]+/', '-', $value) ?? ''), '-'); }
}
