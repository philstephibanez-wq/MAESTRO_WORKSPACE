<?php
declare(strict_types=1);

namespace ASAPRefBook\Reference\Service;

use RuntimeException;

/**
 * PUBLIC SERVICE
 *
 * Role:
 *   Load the generated ASAP source manifest.
 *
 * Contract:
 *   Manifest loading only. No routing, no HTML rendering, no controller logic.
 */
final class ManifestRepository
{
    public function __construct(private readonly string $manifestFile)
    {
    }

    /**
     * @return array<string,mixed>
     */
    public function load(): array
    {
        if (!is_file($this->manifestFile)) {
            throw new RuntimeException('ASAP_REFBOOK_MANIFEST_FILE_MISSING=' . $this->manifestFile);
        }

        $json = json_decode((string) file_get_contents($this->manifestFile), true);
        if (!is_array($json)) {
            throw new RuntimeException('ASAP_REFBOOK_MANIFEST_JSON_INVALID=' . $this->manifestFile);
        }

        if (($json['schema'] ?? null) !== 'ASAP_REFBOOK_SOURCE_MANIFEST_V1') {
            throw new RuntimeException('ASAP_REFBOOK_MANIFEST_SCHEMA_INVALID=' . (string)($json['schema'] ?? 'missing'));
        }

        return $json;
    }
}
