# P113B2A — RefBook symbol kind and smoke fix

## Cause

The generated manifest uses `kind` on symbols, while the symbol template expected `type`.
The P113B2 smoke also included `public/index.php` several times in a single process,
which caused PHP header warnings after the first response was emitted.

## Fix

- `symbol.twig` now accepts `type`, then `kind`, then `symbol`.
- The smoke now runs each route in a child PHP process.

## Scope

Only `H:\ASAP_REF_BOOK`.

No Apache.
No UwAmp.
No `httpd.conf`.
No `.htaccess`.