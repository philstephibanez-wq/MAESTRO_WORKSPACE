<?php
declare(strict_types=1);

namespace ASAPRefBook\Reference\Service;

use RuntimeException;

/**
 * PUBLIC SERVICE
 *
 * Role:
 *   Load RefBook I18N content.
 *
 * Contract:
 *   Structured content only. No routing, no HTTP, no Twig rendering.
 */
final class ReferenceContentService
{
    public const DEFAULT_LANGUAGE = 'fr';

    /** @var list<string> */
    public const SUPPORTED_LANGUAGES = ['fr', 'en', 'es'];

    /** @var array<string,mixed>|null */
    private ?array $content = null;

    public function __construct(
        private readonly string $i18nRoot,
        private readonly string $language = self::DEFAULT_LANGUAGE
    ) {
        if (!in_array($this->language, self::SUPPORTED_LANGUAGES, true)) {
            throw new RuntimeException('ASAP_REFBOOK_LANG_UNSUPPORTED=' . $this->language);
        }
    }

    public function language(): string
    {
        return $this->language;
    }

    /**
     * @return list<string>
     */
    public function supportedLanguages(): array
    {
        return self::SUPPORTED_LANGUAGES;
    }

    /**
     * @return array<string,mixed>
     */
    public function labels(): array
    {
        return $this->load()['labels'] ?? [];
    }

    public function t(string $key): string
    {
        $value = $this->dot($this->labels(), $key);

        if (is_string($value)) {
            return $value;
        }

        return '[*' . $key . '*]';
    }

    /**
     * @return array<string,mixed>
     */
    public function module(): array
    {
        return $this->load()['module'] ?? [];
    }

    /**
     * @return list<array<string,mixed>>
     */
    public function guides(): array
    {
        return array_values(array_filter(
            $this->load()['guides'] ?? [],
            static fn(mixed $page): bool => is_array($page)
        ));
    }

    /**
     * @return list<array<string,string>>
     */
    public function guideNavigation(): array
    {
        return array_map(
            static fn(array $page): array => [
                'slug' => (string) ($page['slug'] ?? ''),
                'title' => (string) ($page['title'] ?? ''),
            ],
            $this->guides()
        );
    }

    /**
     * @return array<string,mixed>|null
     */
    public function guideBySlug(string $slug): ?array
    {
        foreach ($this->guides() as $page) {
            if ((string) ($page['slug'] ?? '') === $slug) {
                return $page;
            }
        }

        return null;
    }

    /**
     * @return list<array<string,string>>
     */
    public function homeCards(): array
    {
        return array_values(array_filter(
            $this->load()['home_cards'] ?? [],
            static fn(mixed $card): bool => is_array($card)
        ));
    }

    public function domainDescription(string $domain): string
    {
        $descriptions = $this->load()['domain_descriptions'] ?? [];

        if (!is_array($descriptions)) {
            return '[*domain.' . $domain . '*]';
        }

        return (string) ($descriptions[$domain] ?? '[*domain.' . $domain . '*]');
    }

    /**
     * @return array<string,mixed>
     */
    private function load(): array
    {
        if ($this->content !== null) {
            return $this->content;
        }

        $file = rtrim($this->i18nRoot, '/\\') . DIRECTORY_SEPARATOR . $this->language . '.json';

        if (!is_file($file)) {
            throw new RuntimeException('ASAP_REFBOOK_I18N_FILE_MISSING=' . $file);
        }

        $json = json_decode((string) file_get_contents($file), true);
        if (!is_array($json)) {
            throw new RuntimeException('ASAP_REFBOOK_I18N_JSON_INVALID=' . $file);
        }

        if (($json['schema'] ?? null) !== 'ASAP_REFBOOK_I18N_V1') {
            throw new RuntimeException('ASAP_REFBOOK_I18N_SCHEMA_INVALID=' . (string) ($json['schema'] ?? 'missing'));
        }

        if (($json['language'] ?? null) !== $this->language) {
            throw new RuntimeException('ASAP_REFBOOK_I18N_LANGUAGE_MISMATCH=' . $file);
        }

        $this->content = $json;

        return $json;
    }

    /**
     * @param array<string,mixed> $data
     */
    private function dot(array $data, string $path): mixed
    {
        $cursor = $data;

        foreach (explode('.', $path) as $segment) {
            if (!is_array($cursor) || !array_key_exists($segment, $cursor)) {
                return null;
            }

            $cursor = $cursor[$segment];
        }

        return $cursor;
    }
}