@echo off
setlocal EnableExtensions

echo MAESTRO_WORKSPACE status check
echo.

if exist "H:\ASAP\.git" (
  echo ==== H:\ASAP ====
  cd /d "H:\ASAP"
  git status
) else (
  echo H:\ASAP not found or not a git repository.
)

echo.

if exist "H:\ASAP_REF_BOOK\.git" (
  echo ==== H:\ASAP_REF_BOOK ====
  cd /d "H:\ASAP_REF_BOOK"
  git status
) else (
  echo H:\ASAP_REF_BOOK not found or not a git repository.
)

echo.
echo Done.
pause
