# MAESTRO_WORKSPACE HANDOFF — 2026-06-09 — ASAP / ASAP_REF_BOOK

## Contexte général

Workspace MAESTRO / ASAP / ASAP_REF_BOOK.

Règles permanentes à respecter :
- 0 fallback silencieux.
- Source de vérité obligatoire avant patch.
- Séparation stricte des responsabilités.
- ASAP = framework / source de vérité technique.
- ASAP_REF_BOOK = consommateur/rendu documentaire, pas scanner sauvage.
- Les livrables doivent être en format ZIP `COPY_TO_<PROJECT>`, à copier à la racine projet, avec `.cmd` de test/apply utilisables depuis VS Code terminal.
- Ne pas déposer de fichiers patch/changelog/TODO à la racine de `H:\`; utiliser `DOC\patches\...`.
- Préférer commandes CMD depuis VS Code terminal.
- Après palier stable : cleanup, commit, push, puis handoff.

## Dépôts / chemins

ASAP :
- Local : `H:\ASAP`
- Branche : `master`
- GitHub public : `https://github.com/philstephibanez-wq/ASAP`

ASAP_REF_BOOK :
- Local : `H:\ASAP_REF_BOOK`
- Branche : `main`
- GitHub public : `https://github.com/philstephibanez-wq/ASAP_REF_BOOK`
- UwAmp : `H:\UwAmp\www\ASAP_REF_BOOK` -> `H:\ASAP_REF_BOOK\public`

## État stable précédent

Avant P113D1 :
- `H:\ASAP` était clean et up to date avec `origin/master`.
- P112Q3E5A était validé, commité et poussé.
- P112Q3F parasite avait été abandonné/nettoyé avant reprise du vrai objectif.

## Palier validé : P113D1 — ASAP RefBook REST API

Objectif :
- ASAP expose une API REST JSON officielle pour le RefBook.
- ASAP_REF_BOOK devra ensuite consommer cette API.
- Le RefBook ne doit pas scanner directement `H:\ASAP`.
- L’API est read-only.

Fonctionnalités posées côté ASAP :
- API REST RefBook.
- Snapshot RefBook JSON.
- Endpoints domains/classes/examples/diagrams.
- Exemples de code.
- Schéma FSM Mermaid utilisé par le framework.
- Test unitaire.
- Smoke test.
- Recette robotisée.
- Intégration à la recette globale ASAP.

Endpoints testés :
- `GET /api/refbook/health`
- `GET /api/refbook/snapshot`
- `GET /api/refbook/domains`
- `GET /api/refbook/classes`
- `GET /api/refbook/classes/ASAP%5CHttp%5CRequest`
- `GET /api/refbook/examples/fsm-state-machine-runtime`
- `GET /api/refbook/diagrams/framework-fsm-runtime`
- `POST /api/refbook/snapshot` -> HTTP 405 attendu, car API read-only.

Résultat navigateur P113D1 :
- Status OK.
- Tous les GET critiques en HTTP 200.
- POST snapshot en HTTP 405, comportement attendu.
- Assets exposés : 5 examples, 2 diagrams.

Sorties validées :
- `P113D1_REFBOOK_REST_API_CONTRACT_UNIT_OK`
- `P113D1_ASAP_REFBOOK_REST_API_SMOKE_OK`
- `ASAP_GLOBAL_REGRESSION_RECIPE_OK`
- `P113D1_ASAP_REFBOOK_REST_API_RECIPE_OK`
- `P113D1C_APPLY_OK`

Commit/push :
- L’utilisateur a indiqué : “push effectué”.
- À la reprise, vérifier simplement :

```cmd
cd /d H:\ASAP
git status
```

Attendu :

```text
Your branch is up to date with 'origin/master'.
nothing to commit, working tree clean
```

## Fichiers/familles ajoutés par P113D1

Côté ASAP, familles importantes :
- `framework\Asap\RefBook\Api\`
- `public\api\`
- `tools\server\`
- `tests\Contract\RefBookRestApiContractTest.php`
- `tools\smoke\p113d1_asap_refbook_rest_api_smoke.php`
- `tools\smoke\run_p113d1_asap_refbook_rest_api_smoke.cmd`
- `tools\recipes\p113d1_asap_refbook_rest_api_robotized_recipe.php`
- `tools\recipes\run_p113d1_asap_refbook_rest_api_robotized_recipe.cmd`
- `tools\recipes\asap_global_regression_recipe.php`
- `DOC\refbook\`
- `DOC\patches\P113D1_ASAP_REFBOOK_REST_API\`

Les livrables intermédiaires P113D1A/P113D1B/P113D1C étaient des corrections d’application et ne doivent pas rester comme docs principales, sauf s’ils sont volontairement archivés. Normalement, seul le dossier principal `DOC\patches\P113D1_ASAP_REFBOOK_REST_API\` doit rester utile.

## Décisions d’architecture confirmées

ASAP :
- Source de vérité technique.
- Reflection = vérité des signatures.
- Attributs RefBook = vérité fonctionnelle.
- Exemples et diagrammes référencés par ID.
- API REST JSON read-only pour exposer cette vérité.

ASAP_REF_BOOK :
- Ne scanne pas le code ASAP.
- N’accède pas directement aux fichiers internes ASAP comme fallback.
- Interroge l’API ASAP.
- Transforme la donnée API en ViewModels.
- Rend Twig/HTML.
- En cas d’API indisponible : erreur claire, pas de fallback silencieux vers vieux JSON.

## Prochaine étape recommandée

P113D2 — ASAP_REF_BOOK consomme l’API REST ASAP.

Objectif P113D2 :
- Ajouter un client REST officiel côté `H:\ASAP_REF_BOOK`.
- Interroger ASAP :
  - health
  - snapshot
  - domains
  - classes
  - examples
  - diagrams
- Construire des ViewModels propres.
- Générer/rendre les pages RefBook automatiquement avec :
  - domaines
  - classes
  - méthodes
  - signatures
  - exemples de code
  - diagrammes Mermaid
  - liens de tests/recettes
- Garder Twig comme rendu uniquement.
- Pas de logique métier dans Twig.
- Pas de scan local.
- Pas de fallback silencieux.

Pré-requis à vérifier avant P113D2 :

```cmd
cd /d H:\ASAP
git status

cd /d H:\ASAP_REF_BOOK
git status
```

Pour tester l’API ASAP disponible :

```cmd
cd /d H:\ASAP
tools\recipes\run_p113d1_asap_refbook_rest_api_robotized_recipe.cmd
```

Puis ouvrir :

```text
http://127.0.0.1:8793/api/refbook/health
http://127.0.0.1:8793/api/refbook/snapshot
http://127.0.0.1:8793/api/refbook/examples/fsm-state-machine-runtime
http://127.0.0.1:8793/api/refbook/diagrams/framework-fsm-runtime
```

## Message de reprise conseillé

On reprend depuis ce handoff MAESTRO_WORKSPACE.

Priorité : P113D2 — ASAP_REF_BOOK consomme l’API REST ASAP RefBook posée en P113D1.

Règles :
- 0 fallback silencieux.
- ASAP_REF_BOOK ne scanne pas ASAP.
- ASAP_REF_BOOK consomme l’API REST ASAP.
- Si l’API est indisponible : erreur explicite.
- Twig = rendu uniquement.
- ViewModel/service/client REST dédiés.
- Livrable ZIP `COPY_TO_ASAP_REF_BOOK`, avec scripts `.cmd`.
- Tests runtime obligatoires avant commit.
